import boto3
from datetime import date, datetime, timedelta, timezone
import csv
import os
from botocore.exceptions import ClientError
from email.mime.application import MIMEApplication
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
iam = boto3.client('iam')
s3 = boto3.client('s3')
cloud_watch = boto3.client('cloudwatch')
required_config_rule = ['access-keys-rotated']
configRuleName = []
fileter_config_rule = []
available_rule_name = []
test_dict = {}
config_res = boto3.client('config')
def check_non_compliant_resource():
    list_config_rule_name = config_res.describe_config_rules()
    for config_rules in list_config_rule_name['ConfigRules']: 
        config_rule_name = config_rules['ConfigRuleName']
        fileter_config_rule.append(config_rule_name)
        if config_rules['ConfigRuleName'] in required_config_rule:
            available_rule_name.append(config_rules['ConfigRuleName'])
    if len(available_rule_name)>0: 
        res1 = config_res.get_compliance_details_by_config_rule(ConfigRuleName=available_rule_name[0],ComplianceTypes=['NON_COMPLIANT'],Limit=100)  
        print(type(res1))
        print(res1) 
        for step1 in res1['EvaluationResults']:
            #print(step1) 
            config_rule_name = step1['EvaluationResultIdentifier']['EvaluationResultQualifier']['ConfigRuleName']
            resource_id = step1['EvaluationResultIdentifier']['EvaluationResultQualifier']['ResourceId']
            resource_type = step1['EvaluationResultIdentifier']['EvaluationResultQualifier']['ResourceType'] 
            compliant_type = step1['ComplianceType']
            test_dict['CONFIG RULE NAME'] = config_rule_name
            test_dict['RESOURCE ID'] = resource_id
            test_dict['RESOURCE TYPE'] = resource_type
            test_dict['COMPLIANCE TYPE'] = compliant_type
            res11 = resource_type.lower()
            res_type = res11.split("::")[1] 
            writer.writerow(test_dict) 
            #print(test_dict) 
def send_mail_to_user(file_name):
    SENDER = "sribalamsc@gmail.com"
    SUBJECT = "individual AWS Security vulnearability Report"
    ATTACHMENT = file_name
    BODY_HTML = """\
    <html>
    <head></head>
    <body>
    <h3>Hi All</h3>
    <h4><b> Attention AWS Account user: </b></h4>
    <p>Please see the attached file for a list of non complaint resources which is created under our AWS account.</p>
    <h4><b>No reply to this e-mail is needed upon fixing the issue.</b></h4>
    </body>
    </html>
    """
    CHARSET = "utf-8"
    ses_res = boto3.client('ses')
    msg = MIMEMultipart('mixed')
    msg = ['subject'] = SUBJECT
    msg['from'] = SENDER
    msg['TO'] = "sribalamsc@gmail.com"
    msg_body = MIMEMultipart('alternative')
    htmlpart = MIMEText(BODY_HTML.encode(CHARSET), 'html',CHARSET)
    msg_body.attach(htmlpart)
    att = MIMEApplication(open(Attachment, 'rb').read())
    att.add_header('content-disposition','attachment',filename=os.path.basename(ATTACHMENT))
    msg.attach(msg_body)
    msg.attach(att)
    try:
         response = ses_res.send_raw_email(
             Source=SENDER,
             Destination=["sribalamsc@gmail.com"
             ],
             RawMessage={
                 'Data':msg.as_string(),
             }
         )
    except ClientError as e:
        print(e.response['Error']['Message'])
    else:
        print("Email sent! Message ID:"),
        print(response['Message Id'])
def lambda_handler(event,context):
    Client = boto3.client('route53')
    fieldnames = ["CONFIG RULE NAME","RESOURCE ID","RESOURCE TYPE","COMPLAINT TYPE","CONTACT"]
    file_name = "/tmp/Resource_report.csv"
    with open (file_name,"w",newine='') as csv_file:
        writer = csv.DictWriter(csv_file,fieldnames=fieldnames)
        Writer.writeheader()
        check_non_compliant_resource(writer)
    send_mail_to_user(filename)         
